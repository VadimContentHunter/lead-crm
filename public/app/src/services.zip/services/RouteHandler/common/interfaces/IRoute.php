<?php

declare(strict_types=1);

namespace  crm\src\services\RouteHandler\common\interfaces;

interface IRoute
{
    public function setPattern(string $pattern): void;

    public function getPattern(): string;

    public function setClassName(string $className): void;

    public function getClassName(): string;

    public function setMethodName(?string $methodName): void;

    public function getMethodName(): ?string;

    /**
     * @param array<string|int,mixed> $data
     */
    public function setExtraData(array $data): void;

    /**
     * @return array<string|int,mixed>
     */
    public function getExtraData(): array;

    public function addExtraData(string $key, mixed $value): void;
}
